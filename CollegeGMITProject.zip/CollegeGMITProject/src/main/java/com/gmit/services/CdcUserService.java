package com.gmit.services;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gmit.model.CdcUser;
import com.gmit.repository.CdcUserRepository;


@Transactional
@Service
public class CdcUserService {
	
	@Autowired
	private final CdcUserRepository cdcUserRepository;
	
	public CdcUserService(CdcUserRepository cdcUserRepository) {
		this.cdcUserRepository=cdcUserRepository;
	}
	
	public CdcUser saveMyUser(CdcUser cdcUser) {
		cdcUser = cdcUserRepository.save(cdcUser);
		
		return cdcUser;
		
	}
	
	public CdcUser findByUsernameAndPassword(String username,String password)
	{
		return cdcUserRepository.findByUsernameAndPassword(username,password);
	}

}
