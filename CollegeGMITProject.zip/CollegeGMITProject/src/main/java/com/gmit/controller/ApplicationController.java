package com.gmit.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpServerErrorException;

import com.gmit.model.CdcUser;
import com.gmit.services.CdcUserService;



@Controller
public class ApplicationController {
	
	@Autowired
	private CdcUserService cdcUserService;
	
	
	@RequestMapping("/")
	public String welcome(HttpServletRequest request)
	{
		return "Index";
	}
	@RequestMapping("/cdclogin")
	public String cdcLogin(HttpServletRequest request)
	{
		return "login";
	}
	
	@RequestMapping("/cdcregister")
	public String cdcregister(HttpServletRequest request)
	{
		return "register";
	}
	@RequestMapping(value="/save-cdc-user", method=RequestMethod.POST)
	public String cdcuserregister(CdcUser cdcUser, HttpServletRequest request)
	{
		//cdcUserService.saveMyUser(cdcUser);
		
		cdcUser = cdcUserService.saveMyUser(cdcUser);
		return "login";
	}
	
	@RequestMapping("/login-cdc-user")
	public String cdclogin(@ModelAttribute CdcUser cdcUser) {
		if(cdcUserService.findByUsernameAndPassword(cdcUser.getUsername(), cdcUser.getPassword()) != null)
		{
			return "homepage";
		}
		else
		{
			return "login";
		}
		
	}

}
